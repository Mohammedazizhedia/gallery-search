package com.gallerysearch.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gallerysearch.app.data.Analyzer
import com.gallerysearch.app.data.MediaItem
import com.gallerysearch.app.data.MediaRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

data class ScanState(
    val running: Boolean = false,
    val done: Boolean = false,
    val dupFiles: Int = 0,
    val dupBytes: Long = 0,
    val corrupt: Int = 0,
)

class GalleryViewModel(app: Application) : AndroidViewModel(app) {
    val items = MutableStateFlow<List<MediaItem>>(emptyList())
    val query = MutableStateFlow("")
    val scan = MutableStateFlow(ScanState())

    fun load() {
        viewModelScope.launch { items.value = MediaRepository.load(getApplication()) }
    }

    fun scanClean() {
        if (scan.value.running) return
        scan.value = ScanState(running = true)
        viewModelScope.launch(Dispatchers.Default) {
            val ctx = getApplication<Application>()
            val all = items.value
            val groups = Analyzer.findDuplicates(ctx, all)
            val extra = groups.flatMap { it.drop(1) }
            val corrupt = all.count { Analyzer.isCorrupt(ctx, it) }
            scan.value = ScanState(
                done = true,
                dupFiles = extra.size,
                dupBytes = extra.sumOf { it.size },
                corrupt = corrupt,
            )
        }
    }
}
