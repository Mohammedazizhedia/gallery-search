package com.gallerysearch.app.ui.clean

import android.text.format.Formatter
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gallerysearch.app.GalleryViewModel
import com.gallerysearch.app.R
import com.gallerysearch.app.ui.components.LineIcon
import com.gallerysearch.app.ui.components.LineIconView
import com.gallerysearch.app.ui.theme.LocalTints
import com.gallerysearch.app.ui.theme.Tint

@Composable
fun CleanScreen(vm: GalleryViewModel) {
    val s by vm.scan.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val tints = LocalTints.current
    val size = Formatter.formatShortFileSize(ctx, s.dupBytes)

    Column(Modifier.verticalScroll(rememberScrollState()).padding(14.dp)) {
        Text(stringResource(R.string.clean_title), style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(tints.accent.bg).padding(14.dp),
        ) {
            Text(stringResource(R.string.clean_save), color = tints.accent.fg, style = MaterialTheme.typography.bodySmall)
            Text(size, color = tints.accent.fg, style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.clean_note), color = tints.accent.fg, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(8.dp))
        CleanRow(LineIcon.Dup, tints.accent, stringResource(R.string.clean_dup),
            if (s.done) stringResource(R.string.files_size, s.dupFiles, size) else "—")
        CleanRow(LineIcon.Broken, tints.danger, stringResource(R.string.clean_corrupt),
            if (s.done) stringResource(R.string.files_count, s.corrupt) else "—")
        CleanRow(LineIcon.Blur, tints.warning, stringResource(R.string.clean_blur),
            stringResource(R.string.clean_soon))
        Spacer(Modifier.height(12.dp))
        Button(onClick = { vm.scanClean() }, enabled = !s.running, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(if (s.running) R.string.scanning else R.string.scan))
        }
    }
}

@Composable
private fun CleanRow(icon: LineIcon, tint: Tint, title: String, subtitle: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(tint.bg),
            contentAlignment = Alignment.Center,
        ) { LineIconView(icon, tint.fg, 36.dp) }
        Column {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
